import KitPy as kp

kp.my_setup(kp,
            entry_points={'console_scripts':['kitpy = kitpy.__main__:main']},
            install_requires=["numpy>=1.26.4",
                              "matplotlib>=3.9.2",
                              "scipy>=1.13.1",
                              "setuptools>=72.1.0"
                              ],
            package_data={'kitpy': ['PyPlot/*.png']},
            include_package_data=True,
            description='A Python Library of Basic Tools',
            python_requires='>=3.9'
            )